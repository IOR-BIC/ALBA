// SPDX-FileCopyrightText: Copyright (c) 2003 Matt Turek
// SPDX-License-Identifier: BSD-4-Clause
#ifndef __DICOM_TYPES_H_
#define __DICOM_TYPES_H_

typedef unsigned short doublebyte;
typedef int quadbyte;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef unsigned int uint;

#endif
