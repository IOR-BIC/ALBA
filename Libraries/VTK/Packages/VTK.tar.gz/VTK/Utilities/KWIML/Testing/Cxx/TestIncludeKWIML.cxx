#include "vtk_kwiml.h"

#include <cstdlib>

int TestIncludeKWIML(int /*argc*/, char* /*argv*/[])
{
  return EXIT_SUCCESS;
}
