#include "vtk_mpi.h"

#include <cstdlib>

int TestIncludeMPI(int /*argc*/, char* /*argv*/[])
{
  return EXIT_SUCCESS;
}
