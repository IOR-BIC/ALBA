Documentation is available on the web at:
  http://www.itk.org/Wiki/MetaIO
