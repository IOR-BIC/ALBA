// SPDX-FileCopyrightText: Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
// SPDX-FileCopyrightText: Copyright 2008 Sandia Corporation
// SPDX-License-Identifier: LicenseRef-BSD-3-Clause-Sandia-USGov

/**
 * @class   vtkSparseArrayToTable
 * @brief   Converts a sparse array to a vtkTable.
 *
 *
 * Converts any sparse array to a vtkTable containing one row for each value
 * stored in the array.  The table will contain one column of coordinates for each
 * dimension in the source array, plus one column of array values.  A common use-case
 * for vtkSparseArrayToTable would be converting a sparse array into a table
 * suitable for use as an input to vtkTableToGraph.
 *
 * The coordinate columns in the output table will be named using the dimension labels
 * from the source array,  The value column name can be explicitly set using
 * SetValueColumn().
 *
 * @par Thanks:
 * Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.
 */

#ifndef vtkSparseArrayToTable_h
#define vtkSparseArrayToTable_h

#include "vtkInfovisCoreModule.h" // For export macro
#include "vtkTableAlgorithm.h"

VTK_ABI_NAMESPACE_BEGIN
class VTKINFOVISCORE_EXPORT vtkSparseArrayToTable : public vtkTableAlgorithm
{
public:
  static vtkSparseArrayToTable* New();
  vtkTypeMacro(vtkSparseArrayToTable, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent) override;

  ///@{
  /**
   * Specify the name of the output table column that contains array values.
   * Default: "value"
   */
  vtkGetStringMacro(ValueColumn);
  vtkSetStringMacro(ValueColumn);
  ///@}

protected:
  vtkSparseArrayToTable();
  ~vtkSparseArrayToTable() override;

  int FillInputPortInformation(int, vtkInformation*) override;

  int RequestData(vtkInformation*, vtkInformationVector**, vtkInformationVector*) override;

  char* ValueColumn;

private:
  vtkSparseArrayToTable(const vtkSparseArrayToTable&) = delete;
  void operator=(const vtkSparseArrayToTable&) = delete;
};

VTK_ABI_NAMESPACE_END
#endif
