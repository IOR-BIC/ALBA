// SPDX-FileCopyrightText: Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
// SPDX-License-Identifier: BSD-3-Clause

#include "vtkBoostDividedEdgeBundling.h"
#include "vtkDataSetAttributes.h"
#include "vtkFloatArray.h"
#include "vtkGraphItem.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkNew.h"
#include "vtkObjectFactory.h"
#include "vtkPoints.h"
#include "vtkStringArray.h"
#include "vtkViewTheme.h"
#include "vtkXMLTreeReader.h"

#include "vtkContext2D.h"
#include "vtkContextActor.h"
#include "vtkContextInteractorStyle.h"
#include "vtkContextItem.h"
#include "vtkContextScene.h"
#include "vtkContextTransform.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkRenderer.h"

#include "vtkRegressionTestImage.h"

//------------------------------------------------------------------------------
void BuildSampleGraph(vtkMutableDirectedGraph* graph)
{
  vtkNew<vtkPoints> points;

  graph->AddVertex();
  points->InsertNextPoint(20, 40, 0);
  graph->AddVertex();
  points->InsertNextPoint(20, 80, 0);
  graph->AddVertex();
  points->InsertNextPoint(20, 120, 0);
  graph->AddVertex();
  points->InsertNextPoint(20, 160, 0);
  graph->AddVertex();
  points->InsertNextPoint(380, 40, 0);
  graph->AddVertex();
  points->InsertNextPoint(380, 80, 0);
  graph->AddVertex();
  points->InsertNextPoint(380, 120, 0);
  graph->AddVertex();
  points->InsertNextPoint(380, 160, 0);
  graph->SetPoints(points);

  graph->AddEdge(0, 4);
  graph->AddEdge(0, 5);
  graph->AddEdge(1, 4);
  graph->AddEdge(1, 5);
  graph->AddEdge(2, 6);
  graph->AddEdge(2, 7);
  graph->AddEdge(3, 6);
  graph->AddEdge(3, 7);

  graph->AddEdge(4, 0);
  graph->AddEdge(5, 0);
  graph->AddEdge(6, 0);
}

//------------------------------------------------------------------------------
void BuildGraphMLGraph(vtkMutableDirectedGraph* graph, std::string file)
{
  vtkNew<vtkXMLTreeReader> reader;
  reader->SetFileName(file.c_str());
  reader->ReadCharDataOn();
  reader->Update();
  vtkTree* tree = reader->GetOutput();
  vtkStringArray* keyArr =
    vtkArrayDownCast<vtkStringArray>(tree->GetVertexData()->GetAbstractArray("key"));
  vtkStringArray* sourceArr =
    vtkArrayDownCast<vtkStringArray>(tree->GetVertexData()->GetAbstractArray("source"));
  vtkStringArray* targetArr =
    vtkArrayDownCast<vtkStringArray>(tree->GetVertexData()->GetAbstractArray("target"));
  vtkStringArray* contentArr =
    vtkArrayDownCast<vtkStringArray>(tree->GetVertexData()->GetAbstractArray(".chardata"));
  double x = 0.0;
  double y = 0.0;
  vtkIdType source = 0;
  vtkIdType target = 0;
  vtkNew<vtkPoints> points;
  graph->SetPoints(points);
  for (vtkIdType i = 0; i < tree->GetNumberOfVertices(); ++i)
  {
    std::string k = keyArr->GetValue(i);
    if (k == "x")
    {
      x = vtkVariant(contentArr->GetValue(i)).ToDouble();
    }
    if (k == "y")
    {
      y = vtkVariant(contentArr->GetValue(i)).ToDouble();
      graph->AddVertex();
      points->InsertNextPoint(x, y, 0.0);
    }
    std::string s = sourceArr->GetValue(i);
    if (!s.empty())
    {
      source = vtkVariant(s).ToInt();
    }
    std::string t = targetArr->GetValue(i);
    if (!t.empty())
    {
      target = vtkVariant(t).ToInt();
      graph->AddEdge(source, target);
    }
  }
}

//------------------------------------------------------------------------------
class vtkBundledGraphItem : public vtkGraphItem
{
public:
  static vtkBundledGraphItem* New();
  vtkTypeMacro(vtkBundledGraphItem, vtkGraphItem);

protected:
  vtkBundledGraphItem() = default;
  ~vtkBundledGraphItem() override = default;

  vtkColor4ub EdgeColor(vtkIdType line, vtkIdType point) override;
  float EdgeWidth(vtkIdType line, vtkIdType point) override;
};

//------------------------------------------------------------------------------
vtkStandardNewMacro(vtkBundledGraphItem);

//------------------------------------------------------------------------------
vtkColor4ub vtkBundledGraphItem::EdgeColor(vtkIdType edgeIdx, vtkIdType pointIdx)
{
  float fraction = static_cast<float>(pointIdx) / (this->NumberOfEdgePoints(edgeIdx) - 1);
  return vtkColor4ub(fraction * 255, 0, 255 - fraction * 255, 255);
}

//------------------------------------------------------------------------------
float vtkBundledGraphItem::EdgeWidth(vtkIdType vtkNotUsed(lineIdx), vtkIdType vtkNotUsed(pointIdx))
{
  return 4.0f;
}

//------------------------------------------------------------------------------
int TestBoostDividedEdgeBundling(int argc, char* argv[])
{
  vtkNew<vtkMutableDirectedGraph> graph;
  vtkNew<vtkBoostDividedEdgeBundling> bundle;

  BuildSampleGraph(graph);
  // BuildGraphMLGraph(graph, "airlines_flipped.graphml");

  bundle->SetInputData(graph);
  bundle->Update();

  vtkDirectedGraph* output = bundle->GetOutput();

  vtkNew<vtkContextActor> actor;

  vtkNew<vtkBundledGraphItem> graphItem;
  graphItem->SetGraph(output);

  vtkNew<vtkContextTransform> trans;
  trans->SetInteractive(true);
  trans->AddItem(graphItem);
  actor->GetScene()->AddItem(trans);

  vtkNew<vtkRenderer> renderer;
  renderer->SetBackground(1.0, 1.0, 1.0);

  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->SetSize(400, 200);
  renderWindow->AddRenderer(renderer);
  renderer->AddActor(actor);

  vtkNew<vtkContextInteractorStyle> interactorStyle;
  interactorStyle->SetScene(actor->GetScene());

  vtkNew<vtkRenderWindowInteractor> interactor;
  interactor->SetInteractorStyle(interactorStyle);
  interactor->SetRenderWindow(renderWindow);
  renderWindow->SetMultiSamples(0);
  renderWindow->Render();

  int retVal = vtkRegressionTestImage(renderWindow);
  if (retVal == vtkRegressionTester::DO_INTERACTOR)
  {
    renderWindow->Render();
    interactor->Start();
    retVal = vtkRegressionTester::PASSED;
  }
  return !retVal;
}
