
/*
	Header file for rs.c
*/


void generate_gf(int *alpha_to, int *index_of);

void gen_poly(int kk, int *alpha_to, int *index_of, int *gg);

void encode_rs(int kk, int *alpha_to, int *index_of, int *gg, int *bb, int *data);

