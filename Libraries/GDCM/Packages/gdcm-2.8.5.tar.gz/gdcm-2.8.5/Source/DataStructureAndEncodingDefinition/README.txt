DICOM Data Structure and Encoding Definitions
Part 3.5
