#!/bin/sh
autoconf
