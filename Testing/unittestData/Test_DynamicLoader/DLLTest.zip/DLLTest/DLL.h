#pragma once


extern "C"
{
	__declspec(dllexport) int AddNums(int a, int b);
};
 
